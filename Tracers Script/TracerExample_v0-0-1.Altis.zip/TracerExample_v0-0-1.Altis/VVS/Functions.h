class VVS
{
	tag = "VVS";
	class functions
	{
		file = "VVS\functions";
		class openVVS {};
		class mainInit {postInit = 1;};
		class buildCfg {};
		class cfgInfo {};
		class mainDisplay {};
		class filterList {};
		class filterType {};
		class spawnVehicle {};
		class checkBox {};
	};
};